package com.calc;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.*;

public class CalculatorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            int num1 = Integer.parseInt(request.getParameter("num1"));
            int num2 = Integer.parseInt(request.getParameter("num2"));
            String op = request.getParameter("operation");

            int result = 0;
            boolean valid = true;

            switch (op) {
                case "add":
                    result = num1 + num2;
                    break;
                case "sub":
                    result = num1 - num2;
                    break;
                case "mul":
                    result = num1 * num2;
                    break;
                case "div":
                    if (num2 != 0)
                        result = num1 / num2;
                    else {
                        out.println("<h3 style='color:red;'>Cannot divide by zero!</h3>");
                        valid = false;
                    }
                    break;
                default:
                    out.println("<h3>Invalid operation selected!</h3>");
                    valid = false;
            }

            if (valid) {
                out.println("<h2>Result: " + result + "</h2>");
            }
        } catch (Exception e) {
            out.println("<h3 style='color:red;'>Invalid input. Please enter numbers only.</h3>");
        }

       out.println("<br><a href='index.html'>Back to Calculator</a>");
    }
}
