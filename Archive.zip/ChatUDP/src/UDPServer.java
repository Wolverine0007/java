import java.net.*;
import java.util.Scanner;

public class UDPServer {
    public static void main(String[] args) throws Exception {
        DatagramSocket socket = new DatagramSocket(1234);
        byte[] buffer = new byte[1024];

        Scanner sc = new Scanner(System.in);
        System.out.println("Server started...");

        while (true) {
            // Receive message
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            socket.receive(packet);
            String clientMsg = new String(packet.getData(), 0, packet.getLength());
            System.out.println("Client: " + clientMsg);

            if (clientMsg.equalsIgnoreCase("exit")) break;

            // Send reply
            System.out.print("You: ");
            String reply = sc.nextLine();
            byte[] replyBytes = reply.getBytes();
            InetAddress clientAddress = packet.getAddress();
            int clientPort = packet.getPort();

            DatagramPacket replyPacket = new DatagramPacket(replyBytes, replyBytes.length, clientAddress, clientPort);
            socket.send(replyPacket);

            if (reply.equalsIgnoreCase("exit")) break;
        }

        socket.close();
        sc.close();
    }
}
