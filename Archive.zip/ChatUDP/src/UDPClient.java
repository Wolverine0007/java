import java.net.*;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) throws Exception {
        DatagramSocket socket = new DatagramSocket();
        InetAddress serverAddress = InetAddress.getByName("localhost");
        Scanner sc = new Scanner(System.in);
        byte[] buffer = new byte[1024];

        System.out.println("Client started...");

        while (true) {
            System.out.print("You: ");
            String message = sc.nextLine();
            byte[] sendBytes = message.getBytes();

            DatagramPacket sendPacket = new DatagramPacket(sendBytes, sendBytes.length, serverAddress, 1234);
            socket.send(sendPacket);

            if (message.equalsIgnoreCase("exit")) break;

            // Receive reply
            DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length);
            socket.receive(receivePacket);
            String reply = new String(receivePacket.getData(), 0, receivePacket.getLength());
            System.out.println("Server: " + reply);

            if (reply.equalsIgnoreCase("exit")) break;
        }

        socket.close();
        sc.close();
    }
}
