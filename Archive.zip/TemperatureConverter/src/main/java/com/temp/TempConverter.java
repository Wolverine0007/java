package com.temp;

import java.io.*;
import javax.servlet.*;

public class TempConverter extends GenericServlet {

    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        

        try {
        	String tempCelsius = request.getParameter("celsius");
            double celsius = Double.parseDouble(tempCelsius);
            double fahrenheit = (celsius * 9 / 5) + 32;

            out.println("<h2>Result</h2>");
            out.println("<p>" + celsius + " °C = " + fahrenheit + " °F</p>");
        } catch (Exception e) {
            out.println("<h3 style='color:red;'>Invalid input! Please enter a valid number.</h3>");
        }

        out.println("<br><a href='index.html'>Try Again</a>");
    }
}
