package com.mit.Emp_Mang_Sys;

import org.hibernate.*;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;
import org.hibernate.Transaction;
import java.util.*;

public class HQL_AGRE_JOIN {
	
	public static void main(String[] args) {
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
	    Metadata md = new MetadataSources(ssr).getMetadataBuilder().build();
	    SessionFactory fac = md.getSessionFactoryBuilder().build();
	    
	    Session sec = fac.openSession();
	    Transaction t = sec.beginTransaction();
		
//	    ********* AGREGATIONS ************
	    
//	    1)SUM 
	    
	    String query1 = "select sum(id) from Employee";
	    Query q1 = sec.createQuery(query1);
	    long sumID = (Long) q1.uniqueResult();
	    System.out.println("Sum of Id Are : " + sumID);
	    
//	    2)Avg
	    
	    String query2 = "select avg(id) from Employee";
	    Query q2 = sec.createQuery(query2);
	    double avrg = (Double) q2.uniqueResult();
	    System.out.println("Average Id are : " + avrg);
	    
//	    3) min max
	    
		String query3  = "select min(id) from Employee";
	    String query4 = "select max(id) from Employee";
	    Query q3 = sec.createQuery(query3);
	    Query q4 = sec.createQuery(query4);
	    
	    int mini = (Integer) q3.uniqueResult();
	    int maxi = (Integer) q4.uniqueResult();
	    
	    System.out.println("Minimum id is : " + mini + " And Maximun id is : " + maxi);
	    
	    
	}
}
