package com.mit.Emp_Mang_Sys;

import org.hibernate.*;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;
import org.hibernate.Transaction;
import java.util.*;

public class HQL_CURD {

    public static void main(String[] args) {
        
        // Step 1: Setting up the Hibernate configuration and session factory
        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata md = new MetadataSources(ssr).getMetadataBuilder().build();
        SessionFactory fac = md.getSessionFactoryBuilder().build();
        
        // Step 2: Opening a session and beginning a transaction
        Session sec = fac.openSession();
        Transaction t = sec.beginTransaction();
        
        
//	    ********** READ ************
	    
	    String query1 = "from Employee as e where e.id = :empId";
	    Query q1 = sec.createQuery(query1);
	    
	    q1.setParameter("empId", 40);
	    
	    List<Employee> list = q1.list();
	    
	    for(Employee e : list) {
	    	System.out.println("ID : " + e.getId());
	    	System.out.println("Fname : " + e.getFname());
	    	System.out.println("Lname : " + e.getLname());
	    	System.out.println("Dept : " + e.getDept());
	    }
    
	    
//		************* UPDATE ***********
	    String query2 = "Update Employee as e set e.id = :newid where e.id = :oldid";
	    Query q2 = sec.createQuery(query2);
	    q2.setParameter("newid", 100);
	    q2.setParameter("oldid", 20);
	    
	    int r1 = q2.executeUpdate();
	    
//		************* DELETE ****************
	    String query3 = "delete from Employee as e where e.id = :ID";
	    Query q3 = sec.createQuery(query3);
	    q3.setParameter("ID", 40);
	   
	    int r2 = q3.executeUpdate();;
	    
	    
	    t.commit();
	    System.out.println("Number of Records Updated : " + r1);
	    System.out.println("Number of Reocrds Deleted : " + r2); 
    }
}
