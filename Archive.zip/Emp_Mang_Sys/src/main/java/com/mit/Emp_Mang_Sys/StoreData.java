package com.mit.Emp_Mang_Sys;

import org.hibernate.*;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;


public class StoreData {
	
	public static void main(String[] args) {
		
		StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata md = new MetadataSources(ssr).getMetadataBuilder().build();
		
		SessionFactory fac = md.getSessionFactoryBuilder().build();
		Session sec = fac.openSession();
		Transaction t = sec.beginTransaction();
		
		Employee e = new Employee();
//		e.setId(10);
//		e.setFname("Prasad");
//		e.setLname("Ingole");
//		e.setDept("HR");
		
//		e.setId(20);
//		e.setDept("HR");
//		e.setFname("Pratik");
//		e.setLname("Bhosale");
		
//		e.setId(30);
//		e.setDept("HR");
//		e.setFname("Prasad");
//		e.setLname("Patil");
		
//		e.setId(40);
//		e.setDept("HR");
//		e.setFname("Shubham");
//		e.setLname("Pawade");
		
//		e.setId(50);
//		e.setDept("HR");
//		e.setFname("Suyash");
//		e.setLname("Dahitule");
		
		sec.save(e);
		
		t.commit();
		sec.close();
		fac.close();
		
	}
	
}
	