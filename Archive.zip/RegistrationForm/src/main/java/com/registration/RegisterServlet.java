package com.registration;

import java.io.*;
import javax.servlet.*;

public class RegisterServlet implements Servlet {
    ServletConfig config = null;

    public void init(ServletConfig config) throws ServletException {
        this.config = config;
    }

    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        out.println("<h2>Registration Successful</h2>");
        out.println("<p>Name: " + name + "</p>");
        out.println("<p>Email: " + email + "</p>");
        out.println("<p>Password: " + password + "</p>");
        out.println("<br><a href='index.html'>Back to form</a>");
    }


    public void destroy() {
        // cleanup if needed
    }

    public ServletConfig getServletConfig() {
        return config;
    }

    public String getServletInfo() {
        return "User Registration Servlet";
    }
}
