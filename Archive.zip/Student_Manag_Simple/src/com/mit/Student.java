package com.mit;

public class Student {
	
	String Name;
	int RollNo;
	int PRN;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getRollNo() {
		return RollNo;
	}
	public void setRollNo(int rollNo) {
		RollNo = rollNo;
	}
	public int getPRN() {
		return PRN;
	}
	public void setPRN(int pRN) {
		PRN = pRN;
	}
	
}
