package form_validation;

import java.io.IOException;
import java.io.ObjectInputFilter.Config;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Validate implements Servlet{
	
	ServletConfig config = null;
	@Override
	public void destroy() {
		System.out.println("Servlet is Distroying !!! ");
	}

	@Override
	public ServletConfig getServletConfig() {
		return config;
	}

	@Override
	public String getServletInfo() {
		return "Servlet is Started on 25 april";
	}

	@Override
	public void init(ServletConfig arg0) throws ServletException {
		this.config = arg0;
		System.out.println("Servlet is initialized !! ");
	}

	@Override
	public void service(ServletRequest req , ServletResponse res) throws ServletException, IOException {
		
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String gender = req.getParameter("gender");
		int age = Integer.parseInt(req.getParameter("age"));
		
		pw.println("Congrats User Registered Successfully !!! ");
		
		pw.println("Name : " + name + "\n Age : " + age);
		
		pw.close();
		
	}

}
