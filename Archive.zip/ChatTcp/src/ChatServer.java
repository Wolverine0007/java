import java.io.*;
import java.net.*;

public class ChatServer {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(1234);
        System.out.println("Server started. Waiting for client...");

        Socket socket = serverSocket.accept();
        System.out.println("Client connected.");

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));

        String msgIn, msgOut;

        while (true) {
            msgIn = in.readLine();
            System.out.println("Client: " + msgIn);

            if (msgIn.equalsIgnoreCase("exit")) break;

            System.out.print("You: ");
            msgOut = userInput.readLine();
            out.println(msgOut);

            if (msgOut.equalsIgnoreCase("exit")) break;
        }

        socket.close();
        serverSocket.close();
    }
}
